import android
app = android.Android()
msg = "Hello from Head First Python on Android"
app.makeToast(msg)
